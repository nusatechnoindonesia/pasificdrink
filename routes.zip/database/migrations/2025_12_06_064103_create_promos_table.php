<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('promos', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('code')->unique();
            $table->string('type'); 
            $table->decimal('value', 10, 2)->nullable();
            $table->decimal('min_purchase', 12, 2)->nullable();
            $table->integer('max_usage')->nullable();
            $table->integer('usage_count')->default(0);
            $table->integer('max_usage_per_user')->default(1);
            $table->date('start_date');
            $table->date('end_date');
            $table->time('start_time')->nullable();
            $table->time('end_time')->nullable();
            $table->json('products')->nullable(); 
            $table->json('excluded_products')->nullable();
            $table->json('categories')->nullable();
            $table->json('payment_methods')->nullable();
            $table->text('description')->nullable();
            $table->string('banner_image')->nullable();
            $table->enum('status', ['active', 'inactive', 'expired'])->default('active');
            $table->boolean('is_public')->default(true);
            $table->timestamps();
            $table->softDeletes();
            
            $table->index('code');
            $table->index('status');
            $table->index('start_date');
            $table->index('end_date');
            $table->index('is_public');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('promos');
    }
};