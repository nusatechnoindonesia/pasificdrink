<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('products', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('slug')->unique();
            $table->string('category');
            $table->decimal('retail_price', 12, 2);
            $table->decimal('wholesale_price', 12, 2);
            $table->integer('min_wholesale')->default(12);
            $table->integer('stock')->default(0);
            $table->string('size')->default('700ml');
            $table->text('description')->nullable();
            $table->string('photo')->nullable();
            $table->enum('status', ['active', 'inactive', 'draft'])->default('active');
            $table->integer('sort_order')->default(0);
            $table->boolean('is_featured')->default(false);
            $table->boolean('is_best_seller')->default(false);
            $table->boolean('has_promo')->default(false);
            $table->json('specifications')->nullable();
            $table->text('ingredients')->nullable();
            $table->string('alcohol_content')->nullable();
            $table->string('country_origin')->nullable();
            $table->integer('views')->default(0);
            $table->integer('sold_count')->default(0);
            $table->timestamps();
            $table->softDeletes();
            $table->timestamp('published_at')->nullable();
            
            // Indexes for performance
            $table->index('category');
            $table->index('status');
            $table->index('slug');
            $table->index('is_featured');
            $table->index('is_best_seller');
            $table->index('created_at');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('products');
    }
};