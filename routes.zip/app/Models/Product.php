<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Str;

class Product extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'name',
        'slug',
        'category',
        'retail_price',
        'wholesale_price',
        'min_wholesale',
        'stock',
        'size',
        'description',
        'photo',
        'status',
        'sort_order',
        'is_featured',
        'is_best_seller',
        'has_promo',
        'specifications',
        'ingredients',
        'alcohol_content',
        'country_origin',
        'views',
        'sold_count',
        'published_at'
    ];

    protected $casts = [
        'retail_price' => 'decimal:2',
        'wholesale_price' => 'decimal:2',
        'stock' => 'integer',
        'min_wholesale' => 'integer',
        'is_featured' => 'boolean',
        'is_best_seller' => 'boolean',
        'has_promo' => 'boolean',
        'specifications' => 'array',
        'views' => 'integer',
        'sold_count' => 'integer',
        'published_at' => 'datetime',
        'sort_order' => 'integer'
    ];

    // Categories constant
    const CATEGORIES = [
        'VIBE',
        'WINE',
        'VODKA',
        'WHISKY',
        'SOJU',
        'COGNAC',
        'GIN',
        'TEQUILLA',
        'LIQUEOR',
        'ARAK',
        'BEER',
        'MIXER DRINK'
    ];

    // Statuses
    const STATUS_ACTIVE = 'active';
    const STATUS_INACTIVE = 'inactive';
    const STATUS_DRAFT = 'draft';

    // Boot method untuk generate slug
    protected static function boot()
    {
        parent::boot();

        static::creating(function ($product) {
            if (empty($product->slug)) {
                $product->slug = Str::slug($product->name);
            }
        });

        static::updating(function ($product) {
            if ($product->isDirty('name')) {
                $product->slug = Str::slug($product->name);
            }
        });
    }

    // Scope for active products
    public function scopeActive($query)
    {
        return $query->where('status', self::STATUS_ACTIVE)
                     ->where(function($q) {
                         $q->whereNull('published_at')
                           ->orWhere('published_at', '<=', now());
                     });
    }

    // Scope by category
    public function scopeByCategory($query, $category)
    {
        return $query->where('category', $category);
    }

    // Scope featured products
    public function scopeFeatured($query)
    {
        return $query->where('is_featured', true);
    }

    // Scope best sellers
    public function scopeBestSellers($query)
    {
        return $query->where('is_best_seller', true)
                     ->orderBy('sold_count', 'desc');
    }

    // Scope low stock
    public function scopeLowStock($query, $threshold = 10)
    {
        return $query->where('stock', '<', $threshold);
    }

    // Check if product is low on stock
    public function getIsLowStockAttribute()
    {
        return $this->stock < 10;
    }

    // Get stock status
    public function getStockStatusAttribute()
    {
        if ($this->stock > 20) return 'good';
        if ($this->stock > 5) return 'warning';
        return 'danger';
    }

    // Get stock status color
    public function getStockStatusColorAttribute()
    {
        if ($this->stock > 20) return 'success';
        if ($this->stock > 5) return 'warning';
        return 'danger';
    }

    // Get formatted price
    public function getFormattedRetailPriceAttribute()
    {
        return 'Rp ' . number_format($this->retail_price, 0, ',', '.');
    }

    public function getFormattedWholesalePriceAttribute()
    {
        return 'Rp ' . number_format($this->wholesale_price, 0, ',', '.');
    }

    // Get photo URL
    public function getPhotoUrlAttribute()
    {
        if (!$this->photo) {
            return asset('images/default-product.png');
        }
        
        if (filter_var($this->photo, FILTER_VALIDATE_URL)) {
            return $this->photo;
        }
        
        return asset('storage/products/' . $this->photo);
    }

    // Get thumbnail URL
    public function getThumbnailUrlAttribute()
    {
        if (!$this->photo) {
            return asset('images/default-product-thumb.png');
        }
        
        $path = pathinfo($this->photo);
        $thumbnail = $path['filename'] . '-thumb.' . $path['extension'];
        
        if (file_exists(storage_path('app/public/products/' . $thumbnail))) {
            return asset('storage/products/' . $thumbnail);
        }
        
        return $this->photo_url;
    }

    // Get product specifications as array
    public function getSpecificationsArrayAttribute()
    {
        return $this->specifications ? json_decode($this->specifications, true) : [];
    }

    // Increase view count
    public function incrementViews()
    {
        $this->increment('views');
    }

    // Update sold count
    public function updateSoldCount($quantity)
    {
        $this->increment('sold_count', $quantity);
    }

    // Check if product is published
    public function getIsPublishedAttribute()
    {
        return $this->status === self::STATUS_ACTIVE && 
               (!$this->published_at || $this->published_at <= now());
    }

    // Relationship dengan promos
    public function promos()
    {
        return $this->belongsToMany(Promo::class, 'promo_product')
                    ->withTimestamps();
    }

    // Relationship dengan orders
    public function orderItems()
    {
        return $this->hasMany(OrderItem::class);
    }
}